function rec(a){
    alert("yes");
}